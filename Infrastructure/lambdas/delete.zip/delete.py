import json
import datetime
import pymysql
import os
import boto3

def lambda_handler(event,context):
    id=event['id']    
    conn=pymysql.connect(
        host=os.environ['host'],
        database=os.environ['database'],
        user=os.environ['user'],
        password=os.environ['password']
        )
    try:
        cursor=conn.cursor()
        sql = "DELETE from inventory where id=%s;"
        cursor.execute(sql, (id))
        conn.commit()
        cursor.close()
        conn.close()
        return {
            'statusCode': 200,
            
            'body': json.dumps('Data has been deleted')
        }
    except:
        return {
            'statusCode':200,
            'body': json.dumps('Failed to delete data')
        }