import json
import datetime
import pymysql
import os
import boto3

def lambda_handler(event,context):
    id=event['id']
    name=event['name']
    quantity=event['quantity']
    location=event['location']
    unitcost=event['unitcost']
    totalcost=str(int(quantity)*int(unitcost))
    lastupdate=str(datetime.datetime.now())
    notes=event['notes']    
    conn=pymysql.connect(
        host=os.environ['host'],
        database=os.environ['database'],
        user=os.environ['user'],
        password=os.environ['password']
        )
    try:
        cursor=conn.cursor()
        sql = "UPDATE inventory SET name=%s,quantity=%s,location=%s,unitcost=%s,totalcost=%s,lastupdate=%s,notes=%s where id=%s;"
        cursor.execute(sql, ( name, quantity, location, unitcost, totalcost, lastupdate, notes,id))
        conn.commit()
        cursor.close()
        conn.close()
        return {
            'statusCode': 200,
            'body': json.dumps('Inventory updated successfully')
        }
    except:
        return {
            'statusCode':200,
            'body': json.dumps('Failed to insert data into inventory. Try again')
        }
