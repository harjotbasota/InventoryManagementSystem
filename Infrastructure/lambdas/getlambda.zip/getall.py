import json
import datetime
import pymysql
import os
import boto3

def lambda_handler(event,context):  
    conn=pymysql.connect(
        host=os.environ['host'],
        database=os.environ['database'],
        user=os.environ['user'],
        password=os.environ['password']
        )
    try:
        cursor=conn.cursor()
        sql = "SELECT * FROM inventory;"
        cursor.execute(sql)
        rows = cursor.fetchall()
        for row in rows:
            print(row)
        cursor.close()
        conn.close()
        return {
            'statusCode': 200,
            'body': json.dumps(rows)
        }
    except:
        return {
            'statusCode':200,
            'body': json.dumps('Failed to get data. Try again')
        }