import json
import datetime
import pymysql
import os
import boto3

def lambda_handler(event,context):
    name=event['name']
    quantity=event['quantity']
    location=event['location']
    unitcost=event['unitcost']
    totalcost=str(int(quantity)*int(unitcost))
    lastupdate=str(datetime.datetime.now())
    notes=event['notes']

    conn=pymysql.connect(
        host=os.environ['host'],
        database=os.environ['database'],
        user=os.environ['user'],
        password=os.environ['password']
        )
    try:
        cursor=conn.cursor()
        sql = "INSERT INTO inventory (name,quantity,location,unitcost,totalcost,lastupdate,notes) VALUES (%s, %s, %s, %s, %s, %s, %s);"
        cursor.execute(sql, ( name, quantity, location, unitcost, totalcost, lastupdate, notes))
        conn.commit()
        cursor.close()
        conn.close()
        return {
            'statusCode': 200,
            'body': json.dumps('Data has been added to inventory')
        }
    except:
        return {
            'statusCode':200,
            'body': json.dumps('Failed to insert data into inventory. Try again')
        }